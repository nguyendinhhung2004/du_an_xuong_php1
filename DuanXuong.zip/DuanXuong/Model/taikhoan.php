<?php
 function check_user($user,$pass){
    $sql = "select *  from nguoidung where user='".$user."'AND pass='".$pass."'";
    $sp = pdo_query_one($sql);
    return  $sp;
}
?>