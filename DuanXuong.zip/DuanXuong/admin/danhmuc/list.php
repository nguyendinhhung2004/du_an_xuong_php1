<div class="form-container">
    <h2>danh sách danh mục</h2>
    <div class="contents">
        <div class="content">
            <table class="danhmuc">
                <tr>
                    
                    <th>Mã loại</th>
                    <th>Tên loại</th>
                    <th>Tùy chỉnh</th>
                </tr>
                <?php
                foreach ($listdanhmuc as $danhmuc) {
                    extract($danhmuc);
                    $suadm = "index.php?act=suadm&id=" . $id;
                    $xoadm = "index.php?act=deletedm&iddm=" . $id;
                    echo ' <tr>
                            
                            
                            <td>'.$id.'</td>
                            <td>'.$name.'</td>
                            <td><a href ="' . $suadm . '"> <input type="button" value="Sửa"></a> 
                            <a href ="' . $xoadm . '" onclick="return confirm(\'Bạn có chắc muốn xóa không?\')"> <input  type="button" value="Xóa"></a></td>
                            
                        </tr>';
                }
                
                ?>
            </table>
        </div>
        <a href="index.php?act=adddm"  ><input type="button" class="submit" value="THÊM MỚI DANH MỤC"></a>

    </div>
</div>