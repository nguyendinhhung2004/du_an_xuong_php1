</div>
</div>
<footer></footer>
  </body>
  <script>
    function toggleSubMenu(element) {
      var subMenu = element.querySelector(".sub-menu");
      subMenu.classList.toggle("active");
    }
  </script>
</html>