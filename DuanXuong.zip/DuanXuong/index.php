<?php
ob_start();
session_start();
include "model/pdo.php";
include "model/sanpham.php";
include "global.php";
include "model/danhmuc.php";
include "model/taikhoan.php";
include "view/header.php";
date_default_timezone_set('Asia/Ho_Chi_Minh');
$spnew = loadall_sanpham_home();
$spgoiy = loadall_sanpham_goiy();
$dsdm = loadall_danhmuc();

if (isset($_GET['act'])) {
    $act = $_GET['act'];

    switch ($act) {
        case 'home':
            include "view/trangchu.php";
            break;

        case 'sanphamct':
            if (isset($_POST['guibinhluan'])) {
                extract($_POST);
                insert_binhluan($idpro, $noidung, $iduser);
            }
            if (isset($_GET['idsp']) && ($_GET > 0)) {
                $id = $_GET['idsp'];
                $onesp = loadone_sanpham($id);
                extract($onesp);
                $sp_cungloai = load_sanpham_cungloai($id, $iddm);
                include "view/chitietsanpham.php";
            } else {
                include "view/trangchu.php";
            }
            break;

        case "sanpham":
            if (isset($_POST['kyw']) && ($_POST['kyw'] != "")) {
                $kyw = $_POST['kyw'];
            } else {
                $kyw = "";
            }
            if (isset($_GET['iddm']) && $_GET['iddm'] > 0) {
                $iddm = $_GET['iddm'];
            } else {
                $iddm = 0;
            }
            $dssp = loadall_sanpham($kyw, $iddm);
            include "view/sanpham.php";
            break;

            case 'dangnhap':
                if (isset($_POST['dangnhap'])) {
                    if (empty($_POST['user']) || empty($_POST['pass'])) {
                        $thongbao = "Vui lòng nhập đầy đủ tài khoản và mật khẩu.";
                    } else {
                        $user = $_POST['user'];
                        $pass = $_POST['pass'];
                        $checkuser = check_user($user, $pass);
                        if (is_array($checkuser)) {
                            $_SESSION['user'] = $checkuser;
                            $thongbao = "Bạn đã đăng nhập thành công!";
                            if ($checkuser['role'] == "admin") {
                                header('Location: admin/index.php?act=home');
                                exit();
                            } else {
                                header('Location: index.php?act=home');
                                exit();
                            }
                        } else {
                            $thongbao = "Tài khoản không tồn tại! Vui lòng kiểm tra hoặc đăng kí tài khoản mới";
                        }
                    }
                }
                include "view/dangnhap.php";
                break;
        default:
            break;
    }
} else {
    include "view/trangchu.php";
}

include "view/footer.php";

ob_end_flush();
?>
