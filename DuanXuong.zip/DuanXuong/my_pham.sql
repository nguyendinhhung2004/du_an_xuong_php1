-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th3 31, 2024 lúc 12:51 PM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `my_pham`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhmuc`
--

CREATE TABLE `danhmuc` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danhmuc`
--

INSERT INTO `danhmuc` (`id`, `name`) VALUES
(6, 'Sữa rửa mặt'),
(7, 'Dầu gội'),
(8, 'Sáp vuốt');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoidung`
--

CREATE TABLE `nguoidung` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `role` enum('nguoidung','admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoidung`
--

INSERT INTO `nguoidung` (`id`, `user`, `pass`, `role`) VALUES
(1, 'admin', '12345', 'admin');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL,
  `hinh` varchar(255) NOT NULL,
  `soluong` int(11) NOT NULL,
  `mota` text DEFAULT NULL,
  `iddm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`id`, `name`, `price`, `hinh`, `soluong`, `mota`, `iddm`) VALUES
(68, 'DẦU GỘI NAM GIỚI TẠO BỌT ', 254000.00, 'Siver-snow.jpg', 254, 'Công dụng:\r\n\r\n–         Dầu gội chiết xuất Nano Bạc làm sạch sâu nhưng vẫn dịu nhẹ cho da\r\n\r\n–         Với hương nước hoa cao cấp, sang trọng giúp lưu hương lâu trên tóc\r\n\r\n–       Sản phẩm tạo bọt trực tiếp giúp làm sạch nhanh hơn, tiện lợi hơn', 7),
(69, 'Sáp Vuốt Tóc Nam Pomade', 299000.00, 'Sáp menitems.jpg', 321, 'Công dụng Sáp Vuốt Tóc Nam Menitems:\r\n\r\nGiữ nếp lâu đến 10 giờ.\r\n\r\nDễ dàng tái tạo phom sau khi đội mũ Bảo Hiểm\r\n\r\nHương nước hoa nhẹ nhàng, lịch lãm với 2 phiên bản mùi hương : Tropical Wind (Thanh mát) và Perfect Night (Trầm ấm)\r\nChất sáp mềm và thơm, dễ tán và xoa ra tay, không làm khô tóc\r\nTạo độ phồng bồng bềnh, tạo độ bóng mờ cho tóc.\r\nGiúp thay đổi vẻ ngoài của tóc, dễ dàng tạo kiểu\r\nGiúp giữ độ ẩm cho tóc hỗ ngăn ngừa gãy tóc và giúp tóc khỏe hơn.\r\nChứa nhiều dưỡng chất giúp tóc chắc khỏe: vitamin B5, chiết xuất nha đam, dầu olive, dầu argan,...\r\n\r\nCông thức Pomade gốc nước giúp dễ dàng gội sạch 100%\r\n\r\nPhù hợp với mọi chất tóc, trừ tóc mỏng\r\n\r\nVỏ hộp kim loại chắc chắn, đẹp mắt, nhỏ gọn\r\nHạn sử dụng: 15 tháng khi chưa mở nắp và 12 tháng sau khi mở nắp\r\n\r\nKhuyến cáo, lưu ý: Tránh tiếp xúc với mắt, tránh xa tầm tay trẻ em. \r\n\r\nHướng dẫn bảo quản:\r\n\r\nĐậy kín nắp ngay sau khi sử dụng.\r\n\r\nKhông để ở nơi ẩm\r\n\r\nKhông để ánh sáng mặt trời chiếu trực tiếp vào sáp\r\n\r\nKhông để trong ngăn mát tủ lạnh\r\n\r\nƯu tiên những nơi thoáng mát như phòng ngủ, phòng học\r\n\r\nHạn chế để trong cốp xe trong thời gian dài\r\n\r\nSử dụng hạt hút ẩm (Silicone) nếu bạn cảm thấy sáp bị ẩm và mốc\r\n\r\nBảo quản tốt nhất ở nhiệt độ phòng 23-27 độ C', 8),
(70, 'Noble Oud | Sữa tắm, dầu ', 799000.00, 'Suatam.webp', 104, 'Sữa tắm sang trọng, tất cả trong một này thực hiện công việc của ba sản phẩm — cung cấp dầu gội bổ sung, dầu xả xa hoa và sữa tắm có mùi thơm đặc biệt giúp làm sạch sâu, nhẹ nhàng.\r\n\r\n18.21 Man Made Wash có độ pH cân bằng, không có chứa chất Sulfate và Paraben.\r\n\r\nCông thức này được tìm thấy để nuôi dưỡng da đầu và giúp mái tóc luôn được khỏe mạnh. Nó hoạt động như một lớp bảo vệ và bổ sung độ ẩm cho da do đó ngăn ngừa da khỏi bị khô.\r\n \r\n\r\nSử dụng thường xuyên giúp thúc đẩy sự tăng trưởng của tóc mới và làm dày tóc. Những thành phần chính được sử dụng trong công thức của sản phẩm này bao gồm:\r\n \r\n· Glycerides Macadamia giúp tăng cường độ ẩm, chống mất nước cho tóc và da.\r\n\r\n· Hydrolyzed Jojoba este giúp tóc hấp thụ các chất dinh dưỡng dễ dàng hơn.\r\n\r\n· Quinoa thuỷ phân (Hydrolyzed Quinoa) thần dược làm đẹp cho tóc, dưỡng ẩm da. Chứa hàm lượng protein cao trong số các loại hạt, đồng thời là loại protein được coi hoàn hảo trong việc tăng cường độ ẩm cho tóc và da.\r\n\r\n18.21 Man Made Wash | Noble Oud có hương thơm hổ phách ngọt ngào và nhựa cây sẽ đưa bạn đến những vùng đất xa xôi trong sự pha trộn của các loại dầu quý giá này. Một chút hương cam bergamot, bưởi và hổ phách mở ra cho vỏ chanh thơm, lá đinh hương và oud hun khói, với ấn tượng cuối cùng của gỗ hồng mộc, hoa vani và xạ hương.\r\n\r\nTrọng lượng: 32oz / 950ml\r\nMade in USA', 7),
(71, 'Tẩy tế bào chết da mặt, cơ thể và da đầu 3 trong 1 cho nam 18.21 Man Made Octane 200 Face, Body & Scalp Scrub 178ml', 490000.00, 'tay_da_chet_18.webp', 237, 'Tẩy tế bào chết da mặt, da đầu và cơ thể 3-in-1 cho nam 18.21 Man Made Octane 200 - Face, Body & Scalp Scrub 178ml\r\n\r\n \r\n\r\nCÔNG DỤNG 18.21 MAN MADE OCTANE 200:\r\n\r\n \r\n\r\n• Làm sạch da chết toàn thân: da mặt, cơ thể và da đầu.\r\n\r\n• Loại bỏ sự tích tụ sản phẩm, dầu nhờn bết dính và gàu trên da đầu để tạo môi trường lành mạnh cho tóc phát triển.\r\n\r\n• Loại bỏ lớp da chết, bong tróc, các mảng sần sùi, bụi bẩn và bã nhờn giúp làn da thông thoáng hơn, lỗ chân lông không còn bị bít tắc và giảm thiểu việc hình thành mụn trứng cá, mụn ẩn,...  mà không làm khô và không gây tổn thương đến làn da.\r\n\r\n• Loại bỏ vết thâm trên khuỷu tay và đầu gối hiệu quả.\r\n\r\n• Mang lại làn da mịn màng ngay sau lần đầu sử dụng.\r\n\r\n• Giúp da sáng mịn, đều màu.\r\n\r\n \r\n\r\nTHÀNH PHẦN VÀNG:\r\n\r\n \r\n\r\n• Hạt tre và Jojoba Esters loại bỏ bụi bẩn, tế bào chết, cặn nhờn.\r\n\r\n• Glycerin dưỡng ẩm.\r\n\r\n• Dầu thầu dầu, Quinoa và Macadamia chống viêm, dưỡng ẩm, chống oxy hóa.\r\n\r\n \r\n\r\nMÙI HƯƠNG NAM TÍNH LƯU LẠI TRÊN DA:\r\n\r\n \r\n\r\n- Sweet_Tobacco: Hương thơm ngọt lịm mật ong say quyện lá thu*c lá tươi sẽ mang đến sức hút nam tính đầy mạnh mẽ.\r\n\r\n \r\n\r\nHƯỚNG DẪN SỬ DỤNG:\r\n\r\n \r\n\r\nDùng 1 – 2 lần một tuần để đạt hiệu quả tốt nhất, giúp bạn nhẹ nhàng tẩy đi các tế bào chết, loại bỏ bụi bẩn và các chất cặn còn lại trên da mặt, cơ thể và da đầu.\r\n\r\n \r\n\r\n• Đối với da mặt và cơ thể: Sau khi rửa sạch mặt với sữa rửa mặt, tắm sạch cơ thể với sữa tắm gội, xả toàn thân 3in1 cho nam 18.21 Man Made Wash hoặc bất kỳ dầu gội nào mà bạn đang sử dụng. Cho một lượng nhỏ sản phẩm tẩy tế bào chết vào tay và nhẹ nhàng chà lên da ướt theo chuyển động tròn nhỏ, sau đó rửa sạch lại với nước.\r\n\r\n(Hoặc trộn lẫn với bất kỳ sữa rửa mặt hoặc sữa tắm nào mà bạn đang sử dụng vào tay và nhẹ nhàng chà lên da ướt theo chuyển động tròn nhỏ, sau đó rửa sạch lại với nước).\r\n\r\n \r\n\r\n• Đối với da đầu: Tạo bọt với sữa tắm gội, xả toàn thân 3in1 cho nam 18.21 Man Made Wash hoặc bất kỳ dầu gội nào mà bạn đang sử dụng, sau đó thêm một lượng vừa đủ sản phẩm tẩy tế bào chết trực tiếp vào bọt dầu gội và nhẹ nhàng xoa vào da đầu theo chuyển động tròn, sau đó rửa sạch lại với nước.\r\n\r\n \r\n\r\nĐIỀU KIỆN BẢO QUẢN:\r\n\r\n \r\n\r\nĐể nơi thoáng mát, tránh nhiệt độ cao và ánh sáng trực tiếp\r\n\r\n \r\n\r\nTên sản phẩm: Tẩy tế bào chết da mặt, da đầu và cơ thể 3-in-1 cho nam 18.21 Man Made Octane 200 - Face, Body & Scalp Scrub 178ml\r\n\r\n• Dung tích: 6oz (tương đương 178ml)\r\n\r\n• Phù hợp mọi loại tóc và da, an toàn với tóc nhuộm.\r\n\r\n• Thương hiệu: 18.21 Man Made\r\n\r\n• Xuất sứ: Mỹ\r\n\r\n• Số lô in trên bao bì\r\n\r\n• Thành phần: Xem trên bao bì\r\n\r\n• Hạn sử dụng: 03 năm kể từ NSX, 12 tháng sau khi mở nắp\r\n\r\n \r\n\r\n*Lưu ý: Bao bì của sản phẩm có thể thay đổi ít nhiều tuỳ theo lô hàng nhập từ Hãng.', 6),
(75, 'Dầu gội sạch gàu, ngăn rụng tóc cho nam Mancave Anti-Dandruff 350ml', 450000.00, 'mancave.webp', 342, 'Dầu gội sạch gàu, ngăn rụng tóc cho nam Mancave Anti-Dandruff 350ml\r\n\r\n- Dung tích: 350ml\r\n- Mùi hương Sea Salt (hương Muối biển): Hương thơm miền biển sảng khoái - Với các nốt hương của Cây bách, Cây thì là biển, Cam Bergamot và Cỏ Vetiver.\r\n- Thương hiệu: Mancave\r\n- Sản xuất tại: Vương Quốc Anh\r\n\r\nDầu gội sạch gàu, ngăn rụng tóc cho nam Mancave Anti-Dandruff nhẹ nhàng làm sạch tóc và da đầu đồng thời giúp loại bỏ gàu trên da đầu và làm dịu kích ứng da đầu.\r\n\r\nChứa Saw Palmetto, một chất ức chế DHT tự nhiên từ đó giảm tình trạng rụng tóc và hói đầu do DHT gây ra, giúp hỗ trợ tóc phát triển khỏe mạnh trong khi Panthenol & Betaine giúp nuôi dưỡng tóc chắc khỏe, phục hồi tóc hư tổn và làm dày tóc.\r\n\r\nNguyên nhân gây rụng tóc?\r\n\r\nNồng độ nội tiết tố nam cao, bao gồm cả DHT, có thể thu nhỏ các nang tóc của bạn cũng như rút ngắn chu kỳ này, khiến tóc mọc ra trông mỏng và dễ gãy hơn, cũng như rụng nhanh hơn. DHT cũng có thể khiến các nang tóc của bạn mất nhiều thời gian hơn để mọc những sợi tóc mới sau khi những sợi tóc cũ rụng đi.\r\n\r\nSaw Palmetto giúp ích như thế nào?\r\n\r\nSaw Palmetto hoạt động như một lá chắn tự nhiên giúp ức chế DHT được tạo ra và chuyển hóa thành Testosterone. Mức độ DHT thấp hơn tương đương với mức độ rụng tóc thấp hơn, từ đó tạo ra một mái tóc đầy đặn hơn, dày hơn và khỏe mạnh hơn.\r\n\r\n93% - Cho biết tóc và da đầu của họ trông khỏe mạnh hơn sau khi sử dụng dầu gội*\r\n90% - Cho biết họ có ít vảy gàu hơn sau khi sử dụng dầu gội*\r\n91% - Cho biết da đầu của họ bớt ngứa và kích ứng hơn sau khi sử dụng dầu gội*\r\n*Dựa trên 2 tuần người dùng dùng thử Dầu gội sạch gàu, ngăn rụng tóc cho nam Mancave Anti-Dandruff với 100 người trả lời.\r\n\r\nCông thức:\r\n\r\n- Chứa hương thơm tự nhiên nên rất an toàn, không gây kích ứng cho da đầu.\r\n- Tất cả các nguyên liệu có nguồn gốc từ cọ đều có nguồn gốc bền vững\r\n- Không chứa bất kỳ chất làm đặc tổng hợp nào\r\n- Không chứa bất kỳ sulfat nào (bao gồm SLES hoặc SLS)\r\n- Được phê duyệt là không có sự tàn ác trong chương trình Leaping Bunny\r\n- Thuần chay\r\n\r\nHướng dẫn sử dụng:\r\n\r\nThoa đều dầu gội Mancave Anti-Dandruff lên tóc đã làm ướt, xoa bóp đều nhẹ nhàng để tạo bọt, đồng thời mát xa da đầu nhiều lần.\r\nSau đó xả sạch tóc với nước.\r\n ', 7);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`),
  ADD KEY `iddm` (`iddm`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `nguoidung`
--
ALTER TABLE `nguoidung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `sanpham_ibfk_1` FOREIGN KEY (`iddm`) REFERENCES `danhmuc` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
