
<main>
    
    <h1 class="h1">ĐĂNG NHẬP TÀI KHOẢN</h1>
    <div class="form-dn">
        <form action="index.php?act=dangnhap" method="post" class="form-dkidn">
            <div class="container">
                <label for="uname"><b>TÊN ĐĂNG NHẬP</b></label>
                <input type="text" placeholder="Nhập tên đăng nhập" name="user" >

                <label for="psw"><b>MẬT KHẨU</b></label>
                <input type="password" placeholder="Nhập mật khẩu" name="pass" >
                <div class="btn-dn">
                    <input type="submit" name="dangnhap" value="Đăng nhập"> <br>
                </div>
            </div>
        </form>
        <h5 style="color: red; text-align: center;">
            <?php
            if(isset($thongbao)&&($thongbao!="")){
                echo $thongbao;
            }
        ?>
        </h5>
    </div>
</main>



<!-- end main -->