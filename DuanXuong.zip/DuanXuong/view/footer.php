
<footer class="footer">
        <div class="container">
            <p>&copy; 2024 Gents - Mỹ phẩm nam</p>
        </div>
    </footer>
</body>

</html>
